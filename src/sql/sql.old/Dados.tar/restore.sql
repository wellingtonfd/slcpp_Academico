--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = salvadel, pg_catalog;

SET search_path = public, pg_catalog;

SET search_path = public, pg_catalog;

--
-- Data for Name: capacidade; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY capacidade (id_capacidade, tipo_capacidade) FROM stdin;
\.
COPY capacidade (id_capacidade, tipo_capacidade) FROM '$$PATH$$/2307.dat';

--
-- Data for Name: end_armazem; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY end_armazem (id_endarmazem, rua_end_armazem, estatos) FROM stdin;
\.
COPY end_armazem (id_endarmazem, rua_end_armazem, estatos) FROM '$$PATH$$/2321.dat';

--
-- Data for Name: local_operacao; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY local_operacao (id_local_oper, desc__local_oper, local_oper) FROM stdin;
\.
COPY local_operacao (id_local_oper, desc__local_oper, local_oper) FROM '$$PATH$$/2341.dat';

--
-- Data for Name: status_armazem; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY status_armazem (id_status_armazem, espec_status_armazem, tipo_status_armazem) FROM stdin;
\.
COPY status_armazem (id_status_armazem, espec_status_armazem, tipo_status_armazem) FROM '$$PATH$$/2354.dat';

--
-- Data for Name: armazem; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY armazem (id_armazem, capacidade_armazem, certificacao_armazem, espec_armazem, estoque_max, estoque_min, id_compatibilidade, id_legenda_compatibilidade, id_local_oper, id_status_armazem, tipo_armazem, id_capacidade, id_endarmazem, local_operacao_id_local_oper, status_armazem_id_status_armazem) FROM stdin;
\.
COPY armazem (id_armazem, capacidade_armazem, certificacao_armazem, espec_armazem, estoque_max, estoque_min, id_compatibilidade, id_legenda_compatibilidade, id_local_oper, id_status_armazem, tipo_armazem, id_capacidade, id_endarmazem, local_operacao_id_local_oper, status_armazem_id_status_armazem) FROM '$$PATH$$/2305.dat';

--
-- Name: armazem_id_armazem_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('armazem_id_armazem_seq', 1, false);


--
-- Name: capacidade_id_capacidade_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('capacidade_id_capacidade_seq', 1, false);


--
-- Data for Name: pais; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY pais (id_pais, nome_pais, siglapais) FROM stdin;
\.
COPY pais (id_pais, nome_pais, siglapais) FROM '$$PATH$$/2349.dat';

--
-- Data for Name: estado; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY estado (id_estado, nome_estado, sigla_estado, id_pais) FROM stdin;
\.
COPY estado (id_estado, nome_estado, sigla_estado, id_pais) FROM '$$PATH$$/2331.dat';

--
-- Data for Name: cidade; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY cidade (id_cidade, nome_cidade, id_estado) FROM stdin;
\.
COPY cidade (id_cidade, nome_cidade, id_estado) FROM '$$PATH$$/2309.dat';

--
-- Name: cidade_id_cidade_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('cidade_id_cidade_seq', 1, false);


--
-- Data for Name: classe; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY classe (id_classe, num_classe, desc_classe) FROM stdin;
\.
COPY classe (id_classe, num_classe, desc_classe) FROM '$$PATH$$/2311.dat';

--
-- Data for Name: combustivel; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY combustivel (id_combustivel, espec_combustivel, nome_combustivel) FROM stdin;
\.
COPY combustivel (id_combustivel, espec_combustivel, nome_combustivel) FROM '$$PATH$$/2312.dat';

--
-- Name: combustivel_id_combustivel_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('combustivel_id_combustivel_seq', 1, false);


--
-- Data for Name: legenda_compatibilidade; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY legenda_compatibilidade (id_legenda_compatibilidade, legenda, desc_legenda) FROM stdin;
\.
COPY legenda_compatibilidade (id_legenda_compatibilidade, legenda, desc_legenda) FROM '$$PATH$$/2339.dat';

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY produto (num_onu, desc_produto, classe) FROM stdin;
\.
COPY produto (num_onu, desc_produto, classe) FROM '$$PATH$$/2351.dat';

--
-- Data for Name: tipo_comp; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY tipo_comp (id_tipo_comp, id_classe, id_legenda) FROM stdin;
\.
COPY tipo_comp (id_tipo_comp, id_classe, id_legenda) FROM '$$PATH$$/2356.dat';

--
-- Data for Name: compatibilidade; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY compatibilidade (id_comptibilidade, numonu, id_tipo_comp) FROM stdin;
\.
COPY compatibilidade (id_comptibilidade, numonu, id_tipo_comp) FROM '$$PATH$$/2314.dat';

--
-- Data for Name: contatos; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY contatos (id_contato, celular, email, radio, site, tel) FROM stdin;
\.
COPY contatos (id_contato, celular, email, radio, site, tel) FROM '$$PATH$$/2315.dat';

--
-- Name: contatos_id_contato_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('contatos_id_contato_seq', 1, false);


--
-- Data for Name: grupo_embalagem; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY grupo_embalagem (id_grupo_embalagem, espec_grupo_embalagem, nome_grupo_embalagem) FROM stdin;
\.
COPY grupo_embalagem (id_grupo_embalagem, espec_grupo_embalagem, nome_grupo_embalagem) FROM '$$PATH$$/2337.dat';

--
-- Data for Name: embalagem; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY embalagem (id_embalagem, capacid_pressao, espec_emabalagem, id_tipo_material, pt_ebulicao, pt_fulgor, id_capacidade, id_compatibilidade, id_grupo_embalagem) FROM stdin;
\.
COPY embalagem (id_embalagem, capacid_pressao, espec_emabalagem, id_tipo_material, pt_ebulicao, pt_fulgor, id_capacidade, id_compatibilidade, id_grupo_embalagem) FROM '$$PATH$$/2319.dat';

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY endereco (id_endereco, bairro, cep, complemento, logadouro, numero, id_cidade, id_estado, id_pais) FROM stdin;
\.
COPY endereco (id_endereco, bairro, cep, complemento, logadouro, numero, id_cidade, id_estado, id_pais) FROM '$$PATH$$/2323.dat';

--
-- Data for Name: tipo_material; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY tipo_material (id_tipo_material, espec_material, nome_material) FROM stdin;
\.
COPY tipo_material (id_tipo_material, espec_material, nome_material) FROM '$$PATH$$/2359.dat';

--
-- Data for Name: epe; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY epe (id_epe, agente_epe, classe_epe, nome_epe, tipo_material_id_material) FROM stdin;
\.
COPY epe (id_epe, agente_epe, classe_epe, nome_epe, tipo_material_id_material) FROM '$$PATH$$/2325.dat';

--
-- Data for Name: epi; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY epi (id_epi, espec_epi, grupo_epi, nome_epi, id_material) FROM stdin;
\.
COPY epi (id_epi, espec_epi, grupo_epi, nome_epi, id_material) FROM '$$PATH$$/2327.dat';

--
-- Data for Name: fornecedor; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY fornecedor (id_fornecedor, cnpj, id_contato, insc_social, nome_fantasia, razao_social, contatos_id_contato, id_endereco) FROM stdin;
\.
COPY fornecedor (id_fornecedor, cnpj, id_contato, insc_social, nome_fantasia, razao_social, contatos_id_contato, id_endereco) FROM '$$PATH$$/2333.dat';

--
-- Data for Name: veiculo; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY veiculo (id_veiculo, ano_veiculo, chassi_veiculo, cor_veiculo, fabricante_veiculo, modelo_veiculo, nome_veiculo, placa_veiculo, id_combustivel) FROM stdin;
\.
COPY veiculo (id_veiculo, ano_veiculo, chassi_veiculo, cor_veiculo, fabricante_veiculo, modelo_veiculo, nome_veiculo, placa_veiculo, id_combustivel) FROM '$$PATH$$/2367.dat';

--
-- Data for Name: tipo_equipamento; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY tipo_equipamento (id_tipo_equipamento, espc_tipo_equipamento, id_epe, nome_tipo_equipamento, epe_id_epe, id_embalagem, id_epi, id_veiculo) FROM stdin;
\.
COPY tipo_equipamento (id_tipo_equipamento, espc_tipo_equipamento, id_epe, nome_tipo_equipamento, epe_id_epe, id_embalagem, id_epi, id_veiculo) FROM '$$PATH$$/2357.dat';

--
-- Data for Name: det_nota; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY det_nota (id_detalhe_nota, dt_pedido, id_fornecedor, id_tipo_equipamento, num_nota, valor_total, valor_unitario, fornecedor_id_fornecedor, id_produto, tipo_equipamento_id_tipo_equipamento) FROM stdin;
\.
COPY det_nota (id_detalhe_nota, dt_pedido, id_fornecedor, id_tipo_equipamento, num_nota, valor_total, valor_unitario, fornecedor_id_fornecedor, id_produto, tipo_equipamento_id_tipo_equipamento) FROM '$$PATH$$/2317.dat';

--
-- Name: det_nota_id_detalhe_nota_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('det_nota_id_detalhe_nota_seq', 1, false);


--
-- Name: embalagem_id_embalagem_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('embalagem_id_embalagem_seq', 1, false);


--
-- Name: end_armazem_id_endarmazem_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('end_armazem_id_endarmazem_seq', 4, true);


--
-- Name: endereco_id_endereco_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('endereco_id_endereco_seq', 1, false);


--
-- Name: epe_id_epe_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('epe_id_epe_seq', 1, false);


--
-- Name: epi_id_epi_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('epi_id_epi_seq', 1, false);


--
-- Data for Name: est_fisico; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY est_fisico (id_est_fisico, esp_est_fisico, nome_est_fisico) FROM stdin;
\.
COPY est_fisico (id_est_fisico, esp_est_fisico, nome_est_fisico) FROM '$$PATH$$/2329.dat';

--
-- Name: est_fisico_id_est_fisico_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('est_fisico_id_est_fisico_seq', 1, false);


--
-- Name: estado_id_estado_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('estado_id_estado_seq', 1, false);


--
-- Name: fornecedor_id_fornecedor_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('fornecedor_id_fornecedor_seq', 1, false);


--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY usuario (id_usuario, ativo, login, senha) FROM stdin;
\.
COPY usuario (id_usuario, ativo, login, senha) FROM '$$PATH$$/2363.dat';

--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY funcionario (id_funcionario, cargo, cpf, dt_admissao, dt_nasc, especializacao, funcao, id_contato, id_endereco, mat_funcionario, nivel_funcionario, nome_funcionario, rg, sb_nome_funcionario, sexo, contatos_id_contato, endereco_id_endereco, id_usuario) FROM stdin;
\.
COPY funcionario (id_funcionario, cargo, cpf, dt_admissao, dt_nasc, especializacao, funcao, id_contato, id_endereco, mat_funcionario, nivel_funcionario, nome_funcionario, rg, sb_nome_funcionario, sexo, contatos_id_contato, endereco_id_endereco, id_usuario) FROM '$$PATH$$/2335.dat';

--
-- Name: funcionario_id_funcionario_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('funcionario_id_funcionario_seq', 1, false);


--
-- Name: grupo_embalagem_id_grupo_embalagem_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('grupo_embalagem_id_grupo_embalagem_seq', 1, false);


--
-- Name: legenda_compatibilidade_id_legenda_compatibilidade_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('legenda_compatibilidade_id_legenda_compatibilidade_seq', 1, false);


--
-- Name: local_operacao_id_local_oper_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('local_operacao_id_local_oper_seq', 1, false);


--
-- Data for Name: movimentacao; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY movimentacao (id_movimentacao, id_endarmazem, id_produto) FROM stdin;
\.
COPY movimentacao (id_movimentacao, id_endarmazem, id_produto) FROM '$$PATH$$/2343.dat';

--
-- Name: movimentacao_id_movimentacao_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('movimentacao_id_movimentacao_seq', 34, true);


--
-- Data for Name: num_cas; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY num_cas (id_num_cas, espc_num_cas, num_cas) FROM stdin;
\.
COPY num_cas (id_num_cas, espc_num_cas, num_cas) FROM '$$PATH$$/2345.dat';

--
-- Name: num_cas_id_num_cas_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('num_cas_id_num_cas_seq', 1, false);


--
-- Data for Name: num_onu; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY num_onu (id_num_onu, desc_prod, nome_prod, num_onu) FROM stdin;
\.
COPY num_onu (id_num_onu, desc_prod, nome_prod, num_onu) FROM '$$PATH$$/2347.dat';

--
-- Name: num_onu_id_num_onu_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('num_onu_id_num_onu_seq', 1, false);


--
-- Name: pais_id_pais_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('pais_id_pais_seq', 1, false);


--
-- Data for Name: roler; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY roler (id_roler, descricao, nome_roler) FROM stdin;
\.
COPY roler (id_roler, descricao, nome_roler) FROM '$$PATH$$/2352.dat';

--
-- Name: roler_id_roler_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('roler_id_roler_seq', 4, true);


--
-- Name: status_armazem_id_status_armazem_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('status_armazem_id_status_armazem_seq', 1, false);


--
-- Name: tipo_equipamento_id_tipo_equipamento_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('tipo_equipamento_id_tipo_equipamento_seq', 1, false);


--
-- Name: tipo_material_id_tipo_material_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('tipo_material_id_tipo_material_seq', 1, false);


--
-- Data for Name: tipo_solicitacao; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY tipo_solicitacao (id_tipo_solicitacao, espec_tipo_solicitacao, id_fornecedor, solicitante, tipo_solicitacao, fornecedor_id_fornecedor, id_armazem, id_funcionario) FROM stdin;
\.
COPY tipo_solicitacao (id_tipo_solicitacao, espec_tipo_solicitacao, id_fornecedor, solicitante, tipo_solicitacao, fornecedor_id_fornecedor, id_armazem, id_funcionario) FROM '$$PATH$$/2361.dat';

--
-- Name: tipo_solicitacao_id_tipo_solicitacao_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('tipo_solicitacao_id_tipo_solicitacao_seq', 1, false);


--
-- Name: usuario_id_usuario_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('usuario_id_usuario_seq', 1, false);


--
-- Data for Name: usuario_roler; Type: TABLE DATA; Schema: public; Owner: slcpp
--

COPY usuario_roler (id, login, roler) FROM stdin;
\.
COPY usuario_roler (id, login, roler) FROM '$$PATH$$/2365.dat';

--
-- Name: usuario_roler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('usuario_roler_id_seq', 4, true);


--
-- Name: veiculo_id_veiculo_seq; Type: SEQUENCE SET; Schema: public; Owner: slcpp
--

SELECT pg_catalog.setval('veiculo_id_veiculo_seq', 1, false);


SET search_path = salvadel, pg_catalog;

--
-- Data for Name: movimentacao; Type: TABLE DATA; Schema: salvadel; Owner: slcpp
--

COPY movimentacao (id_movimentacao, id_endarmazem, id_produto) FROM stdin;
\.
COPY movimentacao (id_movimentacao, id_endarmazem, id_produto) FROM '$$PATH$$/2369.dat';

--
-- PostgreSQL database dump complete
--

