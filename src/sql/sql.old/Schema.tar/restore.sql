--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tipo_comp DROP CONSTRAINT tipo_comp_id_legenda_fkey;
ALTER TABLE ONLY public.tipo_comp DROP CONSTRAINT tipo_comp_id_classe_fkey;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_classe_fkey;
ALTER TABLE ONLY public.movimentacao DROP CONSTRAINT movimentacao_id_produto_fkey;
ALTER TABLE ONLY public.movimentacao DROP CONSTRAINT movimentacao_id_endarmazem_fkey;
ALTER TABLE ONLY public.veiculo DROP CONSTRAINT fk_veiculo_id_combustivel;
ALTER TABLE ONLY public.usuario_roler DROP CONSTRAINT fk_usuario_roler_roler;
ALTER TABLE ONLY public.usuario_roler DROP CONSTRAINT fk_usuario_roler_login;
ALTER TABLE ONLY public.tipo_solicitacao DROP CONSTRAINT fk_tipo_solicitacao_id_funcionario;
ALTER TABLE ONLY public.tipo_solicitacao DROP CONSTRAINT fk_tipo_solicitacao_id_armazem;
ALTER TABLE ONLY public.tipo_solicitacao DROP CONSTRAINT fk_tipo_solicitacao_fornecedor_id_fornecedor;
ALTER TABLE ONLY public.tipo_equipamento DROP CONSTRAINT fk_tipo_equipamento_id_veiculo;
ALTER TABLE ONLY public.tipo_equipamento DROP CONSTRAINT fk_tipo_equipamento_id_epi;
ALTER TABLE ONLY public.tipo_equipamento DROP CONSTRAINT fk_tipo_equipamento_id_embalagem;
ALTER TABLE ONLY public.tipo_equipamento DROP CONSTRAINT fk_tipo_equipamento_epe_id_epe;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT fk_funcionario_id_usuario;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT fk_funcionario_endereco_id_endereco;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT fk_funcionario_contatos_id_contato;
ALTER TABLE ONLY public.fornecedor DROP CONSTRAINT fk_fornecedor_id_endereco;
ALTER TABLE ONLY public.fornecedor DROP CONSTRAINT fk_fornecedor_contatos_id_contato;
ALTER TABLE ONLY public.estado DROP CONSTRAINT fk_estado_id_pais;
ALTER TABLE ONLY public.epi DROP CONSTRAINT fk_epi_id_material;
ALTER TABLE ONLY public.epe DROP CONSTRAINT fk_epe_tipo_material_id_material;
ALTER TABLE ONLY public.endereco DROP CONSTRAINT fk_endereco_id_pais;
ALTER TABLE ONLY public.endereco DROP CONSTRAINT fk_endereco_id_estado;
ALTER TABLE ONLY public.endereco DROP CONSTRAINT fk_endereco_id_cidade;
ALTER TABLE ONLY public.embalagem DROP CONSTRAINT fk_embalagem_id_grupo_embalagem;
ALTER TABLE ONLY public.embalagem DROP CONSTRAINT fk_embalagem_id_capacidade;
ALTER TABLE ONLY public.det_nota DROP CONSTRAINT fk_det_nota_tipo_equipamento_id_tipo_equipamento;
ALTER TABLE ONLY public.det_nota DROP CONSTRAINT fk_det_nota_fornecedor_id_fornecedor;
ALTER TABLE ONLY public.cidade DROP CONSTRAINT fk_cidade_id_estado;
ALTER TABLE ONLY public.armazem DROP CONSTRAINT fk_armazem_status_armazem_id_status_armazem;
ALTER TABLE ONLY public.armazem DROP CONSTRAINT fk_armazem_local_operacao_id_local_oper;
ALTER TABLE ONLY public.armazem DROP CONSTRAINT fk_armazem_id_endarmazem;
ALTER TABLE ONLY public.armazem DROP CONSTRAINT fk_armazem_id_capacidade;
ALTER TABLE ONLY public.compatibilidade DROP CONSTRAINT compatibilidade_numonu_fkey;
ALTER TABLE ONLY public.compatibilidade DROP CONSTRAINT compatibilidade_id_tipo_comp_fkey;
DROP TRIGGER up_endereco_arm ON public.movimentacao;
DROP TRIGGER salva_deletado_movimentacao ON public.movimentacao;
SET search_path = salvadel, pg_catalog;

ALTER TABLE ONLY salvadel.movimentacao DROP CONSTRAINT movimentacao_pkey;
SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.veiculo DROP CONSTRAINT veiculo_pkey;
ALTER TABLE ONLY public.usuario_roler DROP CONSTRAINT usuario_roler_pkey;
ALTER TABLE ONLY public.usuario DROP CONSTRAINT usuario_pkey;
ALTER TABLE ONLY public.tipo_solicitacao DROP CONSTRAINT tipo_solicitacao_pkey;
ALTER TABLE ONLY public.tipo_material DROP CONSTRAINT tipo_material_pkey;
ALTER TABLE ONLY public.tipo_equipamento DROP CONSTRAINT tipo_equipamento_pkey;
ALTER TABLE ONLY public.tipo_comp DROP CONSTRAINT "tipoComp_pkey";
ALTER TABLE ONLY public.status_armazem DROP CONSTRAINT status_armazem_pkey;
ALTER TABLE ONLY public.roler DROP CONSTRAINT roler_pkey;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_pkey;
ALTER TABLE ONLY public.pais DROP CONSTRAINT pais_pkey;
ALTER TABLE ONLY public.num_onu DROP CONSTRAINT num_onu_pkey;
ALTER TABLE ONLY public.num_cas DROP CONSTRAINT num_cas_pkey;
ALTER TABLE ONLY public.movimentacao DROP CONSTRAINT movimentacao_pkey;
ALTER TABLE ONLY public.movimentacao DROP CONSTRAINT movimentacao_id_endarmazem_key;
ALTER TABLE ONLY public.local_operacao DROP CONSTRAINT local_operacao_pkey;
ALTER TABLE ONLY public.legenda_compatibilidade DROP CONSTRAINT legenda_compatibilidade_pkey;
ALTER TABLE ONLY public.grupo_embalagem DROP CONSTRAINT grupo_embalagem_pkey;
ALTER TABLE ONLY public.funcionario DROP CONSTRAINT funcionario_pkey;
ALTER TABLE ONLY public.fornecedor DROP CONSTRAINT fornecedor_pkey;
ALTER TABLE ONLY public.estado DROP CONSTRAINT estado_pkey;
ALTER TABLE ONLY public.est_fisico DROP CONSTRAINT est_fisico_pkey;
ALTER TABLE ONLY public.epi DROP CONSTRAINT epi_pkey;
ALTER TABLE ONLY public.epe DROP CONSTRAINT epe_pkey;
ALTER TABLE ONLY public.endereco DROP CONSTRAINT endereco_pkey;
ALTER TABLE ONLY public.end_armazem DROP CONSTRAINT end_armazem_pkey;
ALTER TABLE ONLY public.embalagem DROP CONSTRAINT embalagem_pkey;
ALTER TABLE ONLY public.det_nota DROP CONSTRAINT det_nota_pkey;
ALTER TABLE ONLY public.contatos DROP CONSTRAINT contatos_pkey;
ALTER TABLE ONLY public.compatibilidade DROP CONSTRAINT compatibilidade_pkey;
ALTER TABLE ONLY public.combustivel DROP CONSTRAINT combustivel_pkey;
ALTER TABLE ONLY public.classe DROP CONSTRAINT classe_pkey;
ALTER TABLE ONLY public.cidade DROP CONSTRAINT cidade_pkey;
ALTER TABLE ONLY public.capacidade DROP CONSTRAINT capacidade_pkey;
ALTER TABLE ONLY public.armazem DROP CONSTRAINT armazem_pkey;
ALTER TABLE public.veiculo ALTER COLUMN id_veiculo DROP DEFAULT;
ALTER TABLE public.usuario_roler ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.usuario ALTER COLUMN id_usuario DROP DEFAULT;
ALTER TABLE public.tipo_solicitacao ALTER COLUMN id_tipo_solicitacao DROP DEFAULT;
ALTER TABLE public.tipo_material ALTER COLUMN id_tipo_material DROP DEFAULT;
ALTER TABLE public.tipo_equipamento ALTER COLUMN id_tipo_equipamento DROP DEFAULT;
ALTER TABLE public.status_armazem ALTER COLUMN id_status_armazem DROP DEFAULT;
ALTER TABLE public.roler ALTER COLUMN id_roler DROP DEFAULT;
ALTER TABLE public.pais ALTER COLUMN id_pais DROP DEFAULT;
ALTER TABLE public.num_onu ALTER COLUMN id_num_onu DROP DEFAULT;
ALTER TABLE public.num_cas ALTER COLUMN id_num_cas DROP DEFAULT;
ALTER TABLE public.movimentacao ALTER COLUMN id_movimentacao DROP DEFAULT;
ALTER TABLE public.local_operacao ALTER COLUMN id_local_oper DROP DEFAULT;
ALTER TABLE public.legenda_compatibilidade ALTER COLUMN id_legenda_compatibilidade DROP DEFAULT;
ALTER TABLE public.grupo_embalagem ALTER COLUMN id_grupo_embalagem DROP DEFAULT;
ALTER TABLE public.funcionario ALTER COLUMN id_funcionario DROP DEFAULT;
ALTER TABLE public.fornecedor ALTER COLUMN id_fornecedor DROP DEFAULT;
ALTER TABLE public.estado ALTER COLUMN id_estado DROP DEFAULT;
ALTER TABLE public.est_fisico ALTER COLUMN id_est_fisico DROP DEFAULT;
ALTER TABLE public.epi ALTER COLUMN id_epi DROP DEFAULT;
ALTER TABLE public.epe ALTER COLUMN id_epe DROP DEFAULT;
ALTER TABLE public.endereco ALTER COLUMN id_endereco DROP DEFAULT;
ALTER TABLE public.end_armazem ALTER COLUMN id_endarmazem DROP DEFAULT;
ALTER TABLE public.embalagem ALTER COLUMN id_embalagem DROP DEFAULT;
ALTER TABLE public.det_nota ALTER COLUMN id_detalhe_nota DROP DEFAULT;
ALTER TABLE public.contatos ALTER COLUMN id_contato DROP DEFAULT;
ALTER TABLE public.combustivel ALTER COLUMN id_combustivel DROP DEFAULT;
ALTER TABLE public.cidade ALTER COLUMN id_cidade DROP DEFAULT;
ALTER TABLE public.capacidade ALTER COLUMN id_capacidade DROP DEFAULT;
ALTER TABLE public.armazem ALTER COLUMN id_armazem DROP DEFAULT;
SET search_path = salvadel, pg_catalog;

DROP TABLE salvadel.movimentacao;
SET search_path = public, pg_catalog;

DROP SEQUENCE public.veiculo_id_veiculo_seq;
DROP TABLE public.veiculo;
DROP VIEW public.usuario_roler_view;
DROP SEQUENCE public.usuario_roler_id_seq;
DROP TABLE public.usuario_roler;
DROP SEQUENCE public.usuario_id_usuario_seq;
DROP TABLE public.usuario;
DROP SEQUENCE public.tipo_solicitacao_id_tipo_solicitacao_seq;
DROP TABLE public.tipo_solicitacao;
DROP SEQUENCE public.tipo_material_id_tipo_material_seq;
DROP TABLE public.tipo_material;
DROP SEQUENCE public.tipo_equipamento_id_tipo_equipamento_seq;
DROP TABLE public.tipo_equipamento;
DROP TABLE public.tipo_comp;
DROP SEQUENCE public.status_armazem_id_status_armazem_seq;
DROP TABLE public.status_armazem;
DROP SEQUENCE public.roler_id_roler_seq;
DROP TABLE public.roler;
DROP TABLE public.produto;
DROP SEQUENCE public.pais_id_pais_seq;
DROP TABLE public.pais;
DROP SEQUENCE public.num_onu_id_num_onu_seq;
DROP TABLE public.num_onu;
DROP SEQUENCE public.num_cas_id_num_cas_seq;
DROP TABLE public.num_cas;
DROP SEQUENCE public.movimentacao_id_movimentacao_seq;
DROP TABLE public.movimentacao;
DROP SEQUENCE public.local_operacao_id_local_oper_seq;
DROP TABLE public.local_operacao;
DROP SEQUENCE public.legenda_compatibilidade_id_legenda_compatibilidade_seq;
DROP TABLE public.legenda_compatibilidade;
DROP SEQUENCE public.grupo_embalagem_id_grupo_embalagem_seq;
DROP TABLE public.grupo_embalagem;
DROP SEQUENCE public.funcionario_id_funcionario_seq;
DROP TABLE public.funcionario;
DROP SEQUENCE public.fornecedor_id_fornecedor_seq;
DROP TABLE public.fornecedor;
DROP SEQUENCE public.estado_id_estado_seq;
DROP TABLE public.estado;
DROP SEQUENCE public.est_fisico_id_est_fisico_seq;
DROP TABLE public.est_fisico;
DROP SEQUENCE public.epi_id_epi_seq;
DROP TABLE public.epi;
DROP SEQUENCE public.epe_id_epe_seq;
DROP TABLE public.epe;
DROP SEQUENCE public.endereco_id_endereco_seq;
DROP TABLE public.endereco;
DROP SEQUENCE public.end_armazem_id_endarmazem_seq;
DROP TABLE public.end_armazem;
DROP SEQUENCE public.embalagem_id_embalagem_seq;
DROP TABLE public.embalagem;
DROP SEQUENCE public.det_nota_id_detalhe_nota_seq;
DROP TABLE public.det_nota;
DROP SEQUENCE public.contatos_id_contato_seq;
DROP TABLE public.contatos;
DROP TABLE public.compatibilidade;
DROP SEQUENCE public.combustivel_id_combustivel_seq;
DROP TABLE public.combustivel;
DROP TABLE public.classe;
DROP SEQUENCE public.cidade_id_cidade_seq;
DROP TABLE public.cidade;
DROP SEQUENCE public.capacidade_id_capacidade_seq;
DROP TABLE public.capacidade;
DROP SEQUENCE public.armazem_id_armazem_seq;
DROP TABLE public.armazem;
DROP FUNCTION public.update_endereco_arm();
DROP FUNCTION public.salva_deletado_movimentacao();
DROP EXTENSION plpgsql;
DROP SCHEMA salvadel;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: salvadel; Type: SCHEMA; Schema: -; Owner: slcpp
--

CREATE SCHEMA salvadel;


ALTER SCHEMA salvadel OWNER TO slcpp;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: salva_deletado_movimentacao(); Type: FUNCTION; Schema: public; Owner: slcpp
--

CREATE FUNCTION salva_deletado_movimentacao() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
		insert into salvadel.movimentacao values (old.id_movimentacao,old.id_endarmazem,old.id_produto);
		return null;
	end;
	$$;


ALTER FUNCTION public.salva_deletado_movimentacao() OWNER TO slcpp;

--
-- Name: update_endereco_arm(); Type: FUNCTION; Schema: public; Owner: slcpp
--

CREATE FUNCTION update_endereco_arm() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		--
		-- Ao inserir em movimentação o endereço inserido sera
		-- atualizado na tabela endereço de armazenagem
		--

		IF (TG_OP = 'INSERT') THEN
			-- se estatos for true retornar null
			UPDATE end_armazem SET estatos = true WHERE id_endarmazem = NEW.id_endarmazem;
			IF NOT FOUND THEN RETURN NULL; END IF;
			RETURN NEW;
		ELSIF (TG_OP = 'DELETE') THEN
			UPDATE end_armazem SET estatos = false WHERE id_endarmazem = OLD.id_endarmazem;
			IF NOT FOUND THEN RETURN NULL; END IF;
			RETURN OLD;
		END IF;
	END;
$$;


ALTER FUNCTION public.update_endereco_arm() OWNER TO slcpp;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: armazem; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE armazem (
    id_armazem integer NOT NULL,
    capacidade_armazem character varying(255),
    certificacao_armazem character varying(255),
    espec_armazem character varying(255),
    estoque_max character varying(255),
    estoque_min character varying(255),
    id_compatibilidade integer,
    id_legenda_compatibilidade integer,
    id_local_oper integer,
    id_status_armazem integer,
    tipo_armazem character varying(255),
    id_capacidade integer,
    id_endarmazem integer,
    local_operacao_id_local_oper integer,
    status_armazem_id_status_armazem integer
);


ALTER TABLE public.armazem OWNER TO slcpp;

--
-- Name: armazem_id_armazem_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE armazem_id_armazem_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.armazem_id_armazem_seq OWNER TO slcpp;

--
-- Name: armazem_id_armazem_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE armazem_id_armazem_seq OWNED BY armazem.id_armazem;


--
-- Name: capacidade; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE capacidade (
    id_capacidade integer NOT NULL,
    tipo_capacidade character varying(255)
);


ALTER TABLE public.capacidade OWNER TO slcpp;

--
-- Name: capacidade_id_capacidade_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE capacidade_id_capacidade_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.capacidade_id_capacidade_seq OWNER TO slcpp;

--
-- Name: capacidade_id_capacidade_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE capacidade_id_capacidade_seq OWNED BY capacidade.id_capacidade;


--
-- Name: cidade; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE cidade (
    id_cidade integer NOT NULL,
    nome_cidade character varying(255),
    id_estado integer
);


ALTER TABLE public.cidade OWNER TO slcpp;

--
-- Name: cidade_id_cidade_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE cidade_id_cidade_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cidade_id_cidade_seq OWNER TO slcpp;

--
-- Name: cidade_id_cidade_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE cidade_id_cidade_seq OWNED BY cidade.id_cidade;


--
-- Name: classe; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE classe (
    id_classe integer NOT NULL,
    num_classe numeric,
    desc_classe character varying(450)
);


ALTER TABLE public.classe OWNER TO slcpp;

--
-- Name: combustivel; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE combustivel (
    id_combustivel integer NOT NULL,
    espec_combustivel character varying(255),
    nome_combustivel character varying(255)
);


ALTER TABLE public.combustivel OWNER TO slcpp;

--
-- Name: combustivel_id_combustivel_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE combustivel_id_combustivel_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.combustivel_id_combustivel_seq OWNER TO slcpp;

--
-- Name: combustivel_id_combustivel_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE combustivel_id_combustivel_seq OWNED BY combustivel.id_combustivel;


--
-- Name: compatibilidade; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE compatibilidade (
    id_comptibilidade integer NOT NULL,
    numonu integer,
    id_tipo_comp integer
);


ALTER TABLE public.compatibilidade OWNER TO slcpp;

--
-- Name: contatos; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE contatos (
    id_contato integer NOT NULL,
    celular character varying(255),
    email character varying(255),
    radio character varying(255),
    site character varying(255),
    tel character varying(255)
);


ALTER TABLE public.contatos OWNER TO slcpp;

--
-- Name: contatos_id_contato_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE contatos_id_contato_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contatos_id_contato_seq OWNER TO slcpp;

--
-- Name: contatos_id_contato_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE contatos_id_contato_seq OWNED BY contatos.id_contato;


--
-- Name: det_nota; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE det_nota (
    id_detalhe_nota integer NOT NULL,
    dt_pedido date,
    id_fornecedor integer,
    id_tipo_equipamento integer,
    num_nota character varying(255),
    valor_total bigint,
    valor_unitario integer,
    fornecedor_id_fornecedor integer,
    id_produto integer,
    tipo_equipamento_id_tipo_equipamento integer
);


ALTER TABLE public.det_nota OWNER TO slcpp;

--
-- Name: det_nota_id_detalhe_nota_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE det_nota_id_detalhe_nota_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.det_nota_id_detalhe_nota_seq OWNER TO slcpp;

--
-- Name: det_nota_id_detalhe_nota_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE det_nota_id_detalhe_nota_seq OWNED BY det_nota.id_detalhe_nota;


--
-- Name: embalagem; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE embalagem (
    id_embalagem integer NOT NULL,
    capacid_pressao character varying(255),
    espec_emabalagem character varying(255),
    id_tipo_material integer,
    pt_ebulicao character varying(255),
    pt_fulgor character varying(255),
    id_capacidade integer,
    id_compatibilidade integer,
    id_grupo_embalagem integer
);


ALTER TABLE public.embalagem OWNER TO slcpp;

--
-- Name: embalagem_id_embalagem_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE embalagem_id_embalagem_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.embalagem_id_embalagem_seq OWNER TO slcpp;

--
-- Name: embalagem_id_embalagem_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE embalagem_id_embalagem_seq OWNED BY embalagem.id_embalagem;


--
-- Name: end_armazem; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE end_armazem (
    id_endarmazem integer NOT NULL,
    rua_end_armazem character varying(255),
    estatos boolean
);


ALTER TABLE public.end_armazem OWNER TO slcpp;

--
-- Name: end_armazem_id_endarmazem_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE end_armazem_id_endarmazem_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.end_armazem_id_endarmazem_seq OWNER TO slcpp;

--
-- Name: end_armazem_id_endarmazem_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE end_armazem_id_endarmazem_seq OWNED BY end_armazem.id_endarmazem;


--
-- Name: endereco; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE endereco (
    id_endereco integer NOT NULL,
    bairro character varying(255),
    cep character varying(255),
    complemento character varying(255),
    logadouro character varying(255),
    numero integer,
    id_cidade integer,
    id_estado integer,
    id_pais integer
);


ALTER TABLE public.endereco OWNER TO slcpp;

--
-- Name: endereco_id_endereco_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE endereco_id_endereco_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.endereco_id_endereco_seq OWNER TO slcpp;

--
-- Name: endereco_id_endereco_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE endereco_id_endereco_seq OWNED BY endereco.id_endereco;


--
-- Name: epe; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE epe (
    id_epe integer NOT NULL,
    agente_epe character varying(255),
    classe_epe character varying(255),
    nome_epe character varying(255),
    tipo_material_id_material integer
);


ALTER TABLE public.epe OWNER TO slcpp;

--
-- Name: epe_id_epe_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE epe_id_epe_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.epe_id_epe_seq OWNER TO slcpp;

--
-- Name: epe_id_epe_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE epe_id_epe_seq OWNED BY epe.id_epe;


--
-- Name: epi; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE epi (
    id_epi integer NOT NULL,
    espec_epi character varying(255),
    grupo_epi character varying(255),
    nome_epi character varying(255),
    id_material integer
);


ALTER TABLE public.epi OWNER TO slcpp;

--
-- Name: epi_id_epi_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE epi_id_epi_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.epi_id_epi_seq OWNER TO slcpp;

--
-- Name: epi_id_epi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE epi_id_epi_seq OWNED BY epi.id_epi;


--
-- Name: est_fisico; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE est_fisico (
    id_est_fisico integer NOT NULL,
    esp_est_fisico character varying(255),
    nome_est_fisico character varying(255)
);


ALTER TABLE public.est_fisico OWNER TO slcpp;

--
-- Name: est_fisico_id_est_fisico_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE est_fisico_id_est_fisico_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.est_fisico_id_est_fisico_seq OWNER TO slcpp;

--
-- Name: est_fisico_id_est_fisico_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE est_fisico_id_est_fisico_seq OWNED BY est_fisico.id_est_fisico;


--
-- Name: estado; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE estado (
    id_estado integer NOT NULL,
    nome_estado character varying(255),
    sigla_estado character varying(255),
    id_pais integer
);


ALTER TABLE public.estado OWNER TO slcpp;

--
-- Name: estado_id_estado_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE estado_id_estado_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estado_id_estado_seq OWNER TO slcpp;

--
-- Name: estado_id_estado_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE estado_id_estado_seq OWNED BY estado.id_estado;


--
-- Name: fornecedor; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE fornecedor (
    id_fornecedor integer NOT NULL,
    cnpj character varying(255),
    id_contato integer,
    insc_social character varying(255),
    nome_fantasia character varying(255),
    razao_social character varying(255),
    contatos_id_contato integer,
    id_endereco integer
);


ALTER TABLE public.fornecedor OWNER TO slcpp;

--
-- Name: fornecedor_id_fornecedor_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE fornecedor_id_fornecedor_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fornecedor_id_fornecedor_seq OWNER TO slcpp;

--
-- Name: fornecedor_id_fornecedor_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE fornecedor_id_fornecedor_seq OWNED BY fornecedor.id_fornecedor;


--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE funcionario (
    id_funcionario integer NOT NULL,
    cargo character varying(255),
    cpf character varying(255),
    dt_admissao date,
    dt_nasc date,
    especializacao character varying(255),
    funcao character varying(255),
    id_contato integer,
    id_endereco integer,
    mat_funcionario integer,
    nivel_funcionario character varying(255),
    nome_funcionario character varying(255),
    rg character varying(255),
    sb_nome_funcionario character varying(255),
    sexo character varying(255),
    contatos_id_contato integer,
    endereco_id_endereco integer,
    id_usuario integer
);


ALTER TABLE public.funcionario OWNER TO slcpp;

--
-- Name: funcionario_id_funcionario_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE funcionario_id_funcionario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.funcionario_id_funcionario_seq OWNER TO slcpp;

--
-- Name: funcionario_id_funcionario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE funcionario_id_funcionario_seq OWNED BY funcionario.id_funcionario;


--
-- Name: grupo_embalagem; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE grupo_embalagem (
    id_grupo_embalagem integer NOT NULL,
    espec_grupo_embalagem character varying(255),
    nome_grupo_embalagem character varying(255)
);


ALTER TABLE public.grupo_embalagem OWNER TO slcpp;

--
-- Name: grupo_embalagem_id_grupo_embalagem_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE grupo_embalagem_id_grupo_embalagem_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grupo_embalagem_id_grupo_embalagem_seq OWNER TO slcpp;

--
-- Name: grupo_embalagem_id_grupo_embalagem_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE grupo_embalagem_id_grupo_embalagem_seq OWNED BY grupo_embalagem.id_grupo_embalagem;


--
-- Name: legenda_compatibilidade; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE legenda_compatibilidade (
    id_legenda_compatibilidade integer NOT NULL,
    legenda character varying(10),
    desc_legenda character varying(150)
);


ALTER TABLE public.legenda_compatibilidade OWNER TO slcpp;

--
-- Name: legenda_compatibilidade_id_legenda_compatibilidade_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE legenda_compatibilidade_id_legenda_compatibilidade_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.legenda_compatibilidade_id_legenda_compatibilidade_seq OWNER TO slcpp;

--
-- Name: legenda_compatibilidade_id_legenda_compatibilidade_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE legenda_compatibilidade_id_legenda_compatibilidade_seq OWNED BY legenda_compatibilidade.id_legenda_compatibilidade;


--
-- Name: local_operacao; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE local_operacao (
    id_local_oper integer NOT NULL,
    desc__local_oper character varying(255),
    local_oper character varying(255)
);


ALTER TABLE public.local_operacao OWNER TO slcpp;

--
-- Name: local_operacao_id_local_oper_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE local_operacao_id_local_oper_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.local_operacao_id_local_oper_seq OWNER TO slcpp;

--
-- Name: local_operacao_id_local_oper_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE local_operacao_id_local_oper_seq OWNED BY local_operacao.id_local_oper;


--
-- Name: movimentacao; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE movimentacao (
    id_movimentacao integer NOT NULL,
    id_endarmazem integer,
    id_produto integer
);


ALTER TABLE public.movimentacao OWNER TO slcpp;

--
-- Name: movimentacao_id_movimentacao_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE movimentacao_id_movimentacao_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.movimentacao_id_movimentacao_seq OWNER TO slcpp;

--
-- Name: movimentacao_id_movimentacao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE movimentacao_id_movimentacao_seq OWNED BY movimentacao.id_movimentacao;


--
-- Name: num_cas; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE num_cas (
    id_num_cas integer NOT NULL,
    espc_num_cas character varying(255),
    num_cas character varying(255)
);


ALTER TABLE public.num_cas OWNER TO slcpp;

--
-- Name: num_cas_id_num_cas_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE num_cas_id_num_cas_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.num_cas_id_num_cas_seq OWNER TO slcpp;

--
-- Name: num_cas_id_num_cas_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE num_cas_id_num_cas_seq OWNED BY num_cas.id_num_cas;


--
-- Name: num_onu; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE num_onu (
    id_num_onu integer NOT NULL,
    desc_prod character varying(255),
    nome_prod character varying(255),
    num_onu character varying(255)
);


ALTER TABLE public.num_onu OWNER TO slcpp;

--
-- Name: num_onu_id_num_onu_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE num_onu_id_num_onu_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.num_onu_id_num_onu_seq OWNER TO slcpp;

--
-- Name: num_onu_id_num_onu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE num_onu_id_num_onu_seq OWNED BY num_onu.id_num_onu;


--
-- Name: pais; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE pais (
    id_pais integer NOT NULL,
    nome_pais character varying(255),
    siglapais character varying(255)
);


ALTER TABLE public.pais OWNER TO slcpp;

--
-- Name: pais_id_pais_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE pais_id_pais_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pais_id_pais_seq OWNER TO slcpp;

--
-- Name: pais_id_pais_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE pais_id_pais_seq OWNED BY pais.id_pais;


--
-- Name: produto; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE produto (
    num_onu integer NOT NULL,
    desc_produto character varying(300),
    classe integer
);


ALTER TABLE public.produto OWNER TO slcpp;

--
-- Name: roler; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE roler (
    id_roler integer NOT NULL,
    descricao character varying(255),
    nome_roler character varying(255)
);


ALTER TABLE public.roler OWNER TO slcpp;

--
-- Name: roler_id_roler_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE roler_id_roler_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roler_id_roler_seq OWNER TO slcpp;

--
-- Name: roler_id_roler_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE roler_id_roler_seq OWNED BY roler.id_roler;


--
-- Name: status_armazem; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE status_armazem (
    id_status_armazem integer NOT NULL,
    espec_status_armazem character varying(255),
    tipo_status_armazem character varying(255)
);


ALTER TABLE public.status_armazem OWNER TO slcpp;

--
-- Name: status_armazem_id_status_armazem_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE status_armazem_id_status_armazem_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_armazem_id_status_armazem_seq OWNER TO slcpp;

--
-- Name: status_armazem_id_status_armazem_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE status_armazem_id_status_armazem_seq OWNED BY status_armazem.id_status_armazem;


--
-- Name: tipo_comp; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE tipo_comp (
    id_tipo_comp integer NOT NULL,
    id_classe integer,
    id_legenda integer
);


ALTER TABLE public.tipo_comp OWNER TO slcpp;

--
-- Name: tipo_equipamento; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE tipo_equipamento (
    id_tipo_equipamento integer NOT NULL,
    espc_tipo_equipamento character varying(255),
    id_epe integer,
    nome_tipo_equipamento character varying(255),
    epe_id_epe integer,
    id_embalagem integer,
    id_epi integer,
    id_veiculo integer
);


ALTER TABLE public.tipo_equipamento OWNER TO slcpp;

--
-- Name: tipo_equipamento_id_tipo_equipamento_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE tipo_equipamento_id_tipo_equipamento_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_equipamento_id_tipo_equipamento_seq OWNER TO slcpp;

--
-- Name: tipo_equipamento_id_tipo_equipamento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE tipo_equipamento_id_tipo_equipamento_seq OWNED BY tipo_equipamento.id_tipo_equipamento;


--
-- Name: tipo_material; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE tipo_material (
    id_tipo_material integer NOT NULL,
    espec_material character varying(255),
    nome_material character varying(255)
);


ALTER TABLE public.tipo_material OWNER TO slcpp;

--
-- Name: tipo_material_id_tipo_material_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE tipo_material_id_tipo_material_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_material_id_tipo_material_seq OWNER TO slcpp;

--
-- Name: tipo_material_id_tipo_material_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE tipo_material_id_tipo_material_seq OWNED BY tipo_material.id_tipo_material;


--
-- Name: tipo_solicitacao; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE tipo_solicitacao (
    id_tipo_solicitacao integer NOT NULL,
    espec_tipo_solicitacao character varying(255),
    id_fornecedor integer,
    solicitante character varying(255),
    tipo_solicitacao character varying(255),
    fornecedor_id_fornecedor integer,
    id_armazem integer,
    id_funcionario integer
);


ALTER TABLE public.tipo_solicitacao OWNER TO slcpp;

--
-- Name: tipo_solicitacao_id_tipo_solicitacao_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE tipo_solicitacao_id_tipo_solicitacao_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_solicitacao_id_tipo_solicitacao_seq OWNER TO slcpp;

--
-- Name: tipo_solicitacao_id_tipo_solicitacao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE tipo_solicitacao_id_tipo_solicitacao_seq OWNED BY tipo_solicitacao.id_tipo_solicitacao;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE usuario (
    id_usuario integer NOT NULL,
    ativo boolean,
    login character varying(255),
    senha character varying(255)
);


ALTER TABLE public.usuario OWNER TO slcpp;

--
-- Name: usuario_id_usuario_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE usuario_id_usuario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_id_usuario_seq OWNER TO slcpp;

--
-- Name: usuario_id_usuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE usuario_id_usuario_seq OWNED BY usuario.id_usuario;


--
-- Name: usuario_roler; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE usuario_roler (
    id integer NOT NULL,
    login integer,
    roler integer
);


ALTER TABLE public.usuario_roler OWNER TO slcpp;

--
-- Name: usuario_roler_id_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE usuario_roler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_roler_id_seq OWNER TO slcpp;

--
-- Name: usuario_roler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE usuario_roler_id_seq OWNED BY usuario_roler.id;


--
-- Name: usuario_roler_view; Type: VIEW; Schema: public; Owner: slcpp
--

CREATE VIEW usuario_roler_view AS
 SELECT usuario.login,
    roler.nome_roler
   FROM ((usuario_roler
     JOIN usuario ON ((usuario_roler.login = usuario.id_usuario)))
     JOIN roler ON ((usuario_roler.roler = roler.id_roler)));


ALTER TABLE public.usuario_roler_view OWNER TO slcpp;

--
-- Name: veiculo; Type: TABLE; Schema: public; Owner: slcpp; Tablespace: 
--

CREATE TABLE veiculo (
    id_veiculo integer NOT NULL,
    ano_veiculo character varying(255),
    chassi_veiculo character varying(255),
    cor_veiculo character varying(255),
    fabricante_veiculo character varying(255),
    modelo_veiculo character varying(255),
    nome_veiculo character varying(255),
    placa_veiculo character varying(255),
    id_combustivel integer
);


ALTER TABLE public.veiculo OWNER TO slcpp;

--
-- Name: veiculo_id_veiculo_seq; Type: SEQUENCE; Schema: public; Owner: slcpp
--

CREATE SEQUENCE veiculo_id_veiculo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.veiculo_id_veiculo_seq OWNER TO slcpp;

--
-- Name: veiculo_id_veiculo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: slcpp
--

ALTER SEQUENCE veiculo_id_veiculo_seq OWNED BY veiculo.id_veiculo;


SET search_path = salvadel, pg_catalog;

--
-- Name: movimentacao; Type: TABLE; Schema: salvadel; Owner: slcpp; Tablespace: 
--

CREATE TABLE movimentacao (
    id_movimentacao integer NOT NULL,
    id_endarmazem integer,
    id_produto integer
);


ALTER TABLE salvadel.movimentacao OWNER TO slcpp;

SET search_path = public, pg_catalog;

--
-- Name: id_armazem; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY armazem ALTER COLUMN id_armazem SET DEFAULT nextval('armazem_id_armazem_seq'::regclass);


--
-- Name: id_capacidade; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY capacidade ALTER COLUMN id_capacidade SET DEFAULT nextval('capacidade_id_capacidade_seq'::regclass);


--
-- Name: id_cidade; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY cidade ALTER COLUMN id_cidade SET DEFAULT nextval('cidade_id_cidade_seq'::regclass);


--
-- Name: id_combustivel; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY combustivel ALTER COLUMN id_combustivel SET DEFAULT nextval('combustivel_id_combustivel_seq'::regclass);


--
-- Name: id_contato; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY contatos ALTER COLUMN id_contato SET DEFAULT nextval('contatos_id_contato_seq'::regclass);


--
-- Name: id_detalhe_nota; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY det_nota ALTER COLUMN id_detalhe_nota SET DEFAULT nextval('det_nota_id_detalhe_nota_seq'::regclass);


--
-- Name: id_embalagem; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY embalagem ALTER COLUMN id_embalagem SET DEFAULT nextval('embalagem_id_embalagem_seq'::regclass);


--
-- Name: id_endarmazem; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY end_armazem ALTER COLUMN id_endarmazem SET DEFAULT nextval('end_armazem_id_endarmazem_seq'::regclass);


--
-- Name: id_endereco; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY endereco ALTER COLUMN id_endereco SET DEFAULT nextval('endereco_id_endereco_seq'::regclass);


--
-- Name: id_epe; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY epe ALTER COLUMN id_epe SET DEFAULT nextval('epe_id_epe_seq'::regclass);


--
-- Name: id_epi; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY epi ALTER COLUMN id_epi SET DEFAULT nextval('epi_id_epi_seq'::regclass);


--
-- Name: id_est_fisico; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY est_fisico ALTER COLUMN id_est_fisico SET DEFAULT nextval('est_fisico_id_est_fisico_seq'::regclass);


--
-- Name: id_estado; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY estado ALTER COLUMN id_estado SET DEFAULT nextval('estado_id_estado_seq'::regclass);


--
-- Name: id_fornecedor; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY fornecedor ALTER COLUMN id_fornecedor SET DEFAULT nextval('fornecedor_id_fornecedor_seq'::regclass);


--
-- Name: id_funcionario; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY funcionario ALTER COLUMN id_funcionario SET DEFAULT nextval('funcionario_id_funcionario_seq'::regclass);


--
-- Name: id_grupo_embalagem; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY grupo_embalagem ALTER COLUMN id_grupo_embalagem SET DEFAULT nextval('grupo_embalagem_id_grupo_embalagem_seq'::regclass);


--
-- Name: id_legenda_compatibilidade; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY legenda_compatibilidade ALTER COLUMN id_legenda_compatibilidade SET DEFAULT nextval('legenda_compatibilidade_id_legenda_compatibilidade_seq'::regclass);


--
-- Name: id_local_oper; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY local_operacao ALTER COLUMN id_local_oper SET DEFAULT nextval('local_operacao_id_local_oper_seq'::regclass);


--
-- Name: id_movimentacao; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY movimentacao ALTER COLUMN id_movimentacao SET DEFAULT nextval('movimentacao_id_movimentacao_seq'::regclass);


--
-- Name: id_num_cas; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY num_cas ALTER COLUMN id_num_cas SET DEFAULT nextval('num_cas_id_num_cas_seq'::regclass);


--
-- Name: id_num_onu; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY num_onu ALTER COLUMN id_num_onu SET DEFAULT nextval('num_onu_id_num_onu_seq'::regclass);


--
-- Name: id_pais; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY pais ALTER COLUMN id_pais SET DEFAULT nextval('pais_id_pais_seq'::regclass);


--
-- Name: id_roler; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY roler ALTER COLUMN id_roler SET DEFAULT nextval('roler_id_roler_seq'::regclass);


--
-- Name: id_status_armazem; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY status_armazem ALTER COLUMN id_status_armazem SET DEFAULT nextval('status_armazem_id_status_armazem_seq'::regclass);


--
-- Name: id_tipo_equipamento; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY tipo_equipamento ALTER COLUMN id_tipo_equipamento SET DEFAULT nextval('tipo_equipamento_id_tipo_equipamento_seq'::regclass);


--
-- Name: id_tipo_material; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY tipo_material ALTER COLUMN id_tipo_material SET DEFAULT nextval('tipo_material_id_tipo_material_seq'::regclass);


--
-- Name: id_tipo_solicitacao; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY tipo_solicitacao ALTER COLUMN id_tipo_solicitacao SET DEFAULT nextval('tipo_solicitacao_id_tipo_solicitacao_seq'::regclass);


--
-- Name: id_usuario; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY usuario ALTER COLUMN id_usuario SET DEFAULT nextval('usuario_id_usuario_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY usuario_roler ALTER COLUMN id SET DEFAULT nextval('usuario_roler_id_seq'::regclass);


--
-- Name: id_veiculo; Type: DEFAULT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY veiculo ALTER COLUMN id_veiculo SET DEFAULT nextval('veiculo_id_veiculo_seq'::regclass);


--
-- Name: armazem_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY armazem
    ADD CONSTRAINT armazem_pkey PRIMARY KEY (id_armazem);


--
-- Name: capacidade_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY capacidade
    ADD CONSTRAINT capacidade_pkey PRIMARY KEY (id_capacidade);


--
-- Name: cidade_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY cidade
    ADD CONSTRAINT cidade_pkey PRIMARY KEY (id_cidade);


--
-- Name: classe_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY classe
    ADD CONSTRAINT classe_pkey PRIMARY KEY (id_classe);


--
-- Name: combustivel_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY combustivel
    ADD CONSTRAINT combustivel_pkey PRIMARY KEY (id_combustivel);


--
-- Name: compatibilidade_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY compatibilidade
    ADD CONSTRAINT compatibilidade_pkey PRIMARY KEY (id_comptibilidade);


--
-- Name: contatos_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY contatos
    ADD CONSTRAINT contatos_pkey PRIMARY KEY (id_contato);


--
-- Name: det_nota_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY det_nota
    ADD CONSTRAINT det_nota_pkey PRIMARY KEY (id_detalhe_nota);


--
-- Name: embalagem_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY embalagem
    ADD CONSTRAINT embalagem_pkey PRIMARY KEY (id_embalagem);


--
-- Name: end_armazem_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY end_armazem
    ADD CONSTRAINT end_armazem_pkey PRIMARY KEY (id_endarmazem);


--
-- Name: endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (id_endereco);


--
-- Name: epe_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY epe
    ADD CONSTRAINT epe_pkey PRIMARY KEY (id_epe);


--
-- Name: epi_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY epi
    ADD CONSTRAINT epi_pkey PRIMARY KEY (id_epi);


--
-- Name: est_fisico_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY est_fisico
    ADD CONSTRAINT est_fisico_pkey PRIMARY KEY (id_est_fisico);


--
-- Name: estado_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY estado
    ADD CONSTRAINT estado_pkey PRIMARY KEY (id_estado);


--
-- Name: fornecedor_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY fornecedor
    ADD CONSTRAINT fornecedor_pkey PRIMARY KEY (id_fornecedor);


--
-- Name: funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (id_funcionario);


--
-- Name: grupo_embalagem_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY grupo_embalagem
    ADD CONSTRAINT grupo_embalagem_pkey PRIMARY KEY (id_grupo_embalagem);


--
-- Name: legenda_compatibilidade_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY legenda_compatibilidade
    ADD CONSTRAINT legenda_compatibilidade_pkey PRIMARY KEY (id_legenda_compatibilidade);


--
-- Name: local_operacao_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY local_operacao
    ADD CONSTRAINT local_operacao_pkey PRIMARY KEY (id_local_oper);


--
-- Name: movimentacao_id_endarmazem_key; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY movimentacao
    ADD CONSTRAINT movimentacao_id_endarmazem_key UNIQUE (id_endarmazem);


--
-- Name: movimentacao_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY movimentacao
    ADD CONSTRAINT movimentacao_pkey PRIMARY KEY (id_movimentacao);


--
-- Name: num_cas_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY num_cas
    ADD CONSTRAINT num_cas_pkey PRIMARY KEY (id_num_cas);


--
-- Name: num_onu_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY num_onu
    ADD CONSTRAINT num_onu_pkey PRIMARY KEY (id_num_onu);


--
-- Name: pais_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY pais
    ADD CONSTRAINT pais_pkey PRIMARY KEY (id_pais);


--
-- Name: produto_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (num_onu);


--
-- Name: roler_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY roler
    ADD CONSTRAINT roler_pkey PRIMARY KEY (id_roler);


--
-- Name: status_armazem_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY status_armazem
    ADD CONSTRAINT status_armazem_pkey PRIMARY KEY (id_status_armazem);


--
-- Name: tipoComp_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY tipo_comp
    ADD CONSTRAINT "tipoComp_pkey" PRIMARY KEY (id_tipo_comp);


--
-- Name: tipo_equipamento_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY tipo_equipamento
    ADD CONSTRAINT tipo_equipamento_pkey PRIMARY KEY (id_tipo_equipamento);


--
-- Name: tipo_material_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY tipo_material
    ADD CONSTRAINT tipo_material_pkey PRIMARY KEY (id_tipo_material);


--
-- Name: tipo_solicitacao_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY tipo_solicitacao
    ADD CONSTRAINT tipo_solicitacao_pkey PRIMARY KEY (id_tipo_solicitacao);


--
-- Name: usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id_usuario);


--
-- Name: usuario_roler_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY usuario_roler
    ADD CONSTRAINT usuario_roler_pkey PRIMARY KEY (id);


--
-- Name: veiculo_pkey; Type: CONSTRAINT; Schema: public; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY veiculo
    ADD CONSTRAINT veiculo_pkey PRIMARY KEY (id_veiculo);


SET search_path = salvadel, pg_catalog;

--
-- Name: movimentacao_pkey; Type: CONSTRAINT; Schema: salvadel; Owner: slcpp; Tablespace: 
--

ALTER TABLE ONLY movimentacao
    ADD CONSTRAINT movimentacao_pkey PRIMARY KEY (id_movimentacao);


SET search_path = public, pg_catalog;

--
-- Name: salva_deletado_movimentacao; Type: TRIGGER; Schema: public; Owner: slcpp
--

CREATE TRIGGER salva_deletado_movimentacao AFTER DELETE ON movimentacao FOR EACH ROW EXECUTE PROCEDURE salva_deletado_movimentacao();


--
-- Name: up_endereco_arm; Type: TRIGGER; Schema: public; Owner: slcpp
--

CREATE TRIGGER up_endereco_arm AFTER INSERT OR DELETE ON movimentacao FOR EACH ROW EXECUTE PROCEDURE update_endereco_arm();


--
-- Name: compatibilidade_id_tipo_comp_fkey; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY compatibilidade
    ADD CONSTRAINT compatibilidade_id_tipo_comp_fkey FOREIGN KEY (id_tipo_comp) REFERENCES tipo_comp(id_tipo_comp);


--
-- Name: compatibilidade_numonu_fkey; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY compatibilidade
    ADD CONSTRAINT compatibilidade_numonu_fkey FOREIGN KEY (numonu) REFERENCES produto(num_onu);


--
-- Name: fk_armazem_id_capacidade; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY armazem
    ADD CONSTRAINT fk_armazem_id_capacidade FOREIGN KEY (id_capacidade) REFERENCES capacidade(id_capacidade);


--
-- Name: fk_armazem_id_endarmazem; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY armazem
    ADD CONSTRAINT fk_armazem_id_endarmazem FOREIGN KEY (id_endarmazem) REFERENCES end_armazem(id_endarmazem);


--
-- Name: fk_armazem_local_operacao_id_local_oper; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY armazem
    ADD CONSTRAINT fk_armazem_local_operacao_id_local_oper FOREIGN KEY (local_operacao_id_local_oper) REFERENCES local_operacao(id_local_oper);


--
-- Name: fk_armazem_status_armazem_id_status_armazem; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY armazem
    ADD CONSTRAINT fk_armazem_status_armazem_id_status_armazem FOREIGN KEY (status_armazem_id_status_armazem) REFERENCES status_armazem(id_status_armazem);


--
-- Name: fk_cidade_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY cidade
    ADD CONSTRAINT fk_cidade_id_estado FOREIGN KEY (id_estado) REFERENCES estado(id_estado);


--
-- Name: fk_det_nota_fornecedor_id_fornecedor; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY det_nota
    ADD CONSTRAINT fk_det_nota_fornecedor_id_fornecedor FOREIGN KEY (fornecedor_id_fornecedor) REFERENCES fornecedor(id_fornecedor);


--
-- Name: fk_det_nota_tipo_equipamento_id_tipo_equipamento; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY det_nota
    ADD CONSTRAINT fk_det_nota_tipo_equipamento_id_tipo_equipamento FOREIGN KEY (tipo_equipamento_id_tipo_equipamento) REFERENCES tipo_equipamento(id_tipo_equipamento);


--
-- Name: fk_embalagem_id_capacidade; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY embalagem
    ADD CONSTRAINT fk_embalagem_id_capacidade FOREIGN KEY (id_capacidade) REFERENCES capacidade(id_capacidade);


--
-- Name: fk_embalagem_id_grupo_embalagem; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY embalagem
    ADD CONSTRAINT fk_embalagem_id_grupo_embalagem FOREIGN KEY (id_grupo_embalagem) REFERENCES grupo_embalagem(id_grupo_embalagem);


--
-- Name: fk_endereco_id_cidade; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY endereco
    ADD CONSTRAINT fk_endereco_id_cidade FOREIGN KEY (id_cidade) REFERENCES cidade(id_cidade);


--
-- Name: fk_endereco_id_estado; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY endereco
    ADD CONSTRAINT fk_endereco_id_estado FOREIGN KEY (id_estado) REFERENCES estado(id_estado);


--
-- Name: fk_endereco_id_pais; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY endereco
    ADD CONSTRAINT fk_endereco_id_pais FOREIGN KEY (id_pais) REFERENCES pais(id_pais);


--
-- Name: fk_epe_tipo_material_id_material; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY epe
    ADD CONSTRAINT fk_epe_tipo_material_id_material FOREIGN KEY (tipo_material_id_material) REFERENCES tipo_material(id_tipo_material);


--
-- Name: fk_epi_id_material; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY epi
    ADD CONSTRAINT fk_epi_id_material FOREIGN KEY (id_material) REFERENCES tipo_material(id_tipo_material);


--
-- Name: fk_estado_id_pais; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY estado
    ADD CONSTRAINT fk_estado_id_pais FOREIGN KEY (id_pais) REFERENCES pais(id_pais);


--
-- Name: fk_fornecedor_contatos_id_contato; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY fornecedor
    ADD CONSTRAINT fk_fornecedor_contatos_id_contato FOREIGN KEY (contatos_id_contato) REFERENCES contatos(id_contato);


--
-- Name: fk_fornecedor_id_endereco; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY fornecedor
    ADD CONSTRAINT fk_fornecedor_id_endereco FOREIGN KEY (id_endereco) REFERENCES endereco(id_endereco);


--
-- Name: fk_funcionario_contatos_id_contato; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY funcionario
    ADD CONSTRAINT fk_funcionario_contatos_id_contato FOREIGN KEY (contatos_id_contato) REFERENCES contatos(id_contato);


--
-- Name: fk_funcionario_endereco_id_endereco; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY funcionario
    ADD CONSTRAINT fk_funcionario_endereco_id_endereco FOREIGN KEY (endereco_id_endereco) REFERENCES endereco(id_endereco);


--
-- Name: fk_funcionario_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY funcionario
    ADD CONSTRAINT fk_funcionario_id_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario);


--
-- Name: fk_tipo_equipamento_epe_id_epe; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY tipo_equipamento
    ADD CONSTRAINT fk_tipo_equipamento_epe_id_epe FOREIGN KEY (epe_id_epe) REFERENCES epe(id_epe);


--
-- Name: fk_tipo_equipamento_id_embalagem; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY tipo_equipamento
    ADD CONSTRAINT fk_tipo_equipamento_id_embalagem FOREIGN KEY (id_embalagem) REFERENCES embalagem(id_embalagem);


--
-- Name: fk_tipo_equipamento_id_epi; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY tipo_equipamento
    ADD CONSTRAINT fk_tipo_equipamento_id_epi FOREIGN KEY (id_epi) REFERENCES epi(id_epi);


--
-- Name: fk_tipo_equipamento_id_veiculo; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY tipo_equipamento
    ADD CONSTRAINT fk_tipo_equipamento_id_veiculo FOREIGN KEY (id_veiculo) REFERENCES veiculo(id_veiculo);


--
-- Name: fk_tipo_solicitacao_fornecedor_id_fornecedor; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY tipo_solicitacao
    ADD CONSTRAINT fk_tipo_solicitacao_fornecedor_id_fornecedor FOREIGN KEY (fornecedor_id_fornecedor) REFERENCES fornecedor(id_fornecedor);


--
-- Name: fk_tipo_solicitacao_id_armazem; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY tipo_solicitacao
    ADD CONSTRAINT fk_tipo_solicitacao_id_armazem FOREIGN KEY (id_armazem) REFERENCES armazem(id_armazem);


--
-- Name: fk_tipo_solicitacao_id_funcionario; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY tipo_solicitacao
    ADD CONSTRAINT fk_tipo_solicitacao_id_funcionario FOREIGN KEY (id_funcionario) REFERENCES funcionario(id_funcionario);


--
-- Name: fk_usuario_roler_login; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY usuario_roler
    ADD CONSTRAINT fk_usuario_roler_login FOREIGN KEY (login) REFERENCES usuario(id_usuario);


--
-- Name: fk_usuario_roler_roler; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY usuario_roler
    ADD CONSTRAINT fk_usuario_roler_roler FOREIGN KEY (roler) REFERENCES roler(id_roler);


--
-- Name: fk_veiculo_id_combustivel; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY veiculo
    ADD CONSTRAINT fk_veiculo_id_combustivel FOREIGN KEY (id_combustivel) REFERENCES combustivel(id_combustivel);


--
-- Name: movimentacao_id_endarmazem_fkey; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY movimentacao
    ADD CONSTRAINT movimentacao_id_endarmazem_fkey FOREIGN KEY (id_endarmazem) REFERENCES end_armazem(id_endarmazem);


--
-- Name: movimentacao_id_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY movimentacao
    ADD CONSTRAINT movimentacao_id_produto_fkey FOREIGN KEY (id_produto) REFERENCES produto(num_onu);


--
-- Name: produto_classe_fkey; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY produto
    ADD CONSTRAINT produto_classe_fkey FOREIGN KEY (classe) REFERENCES classe(id_classe);


--
-- Name: tipo_comp_id_classe_fkey; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY tipo_comp
    ADD CONSTRAINT tipo_comp_id_classe_fkey FOREIGN KEY (id_classe) REFERENCES classe(id_classe);


--
-- Name: tipo_comp_id_legenda_fkey; Type: FK CONSTRAINT; Schema: public; Owner: slcpp
--

ALTER TABLE ONLY tipo_comp
    ADD CONSTRAINT tipo_comp_id_legenda_fkey FOREIGN KEY (id_legenda) REFERENCES legenda_compatibilidade(id_legenda_compatibilidade);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

